from avant_lexer import main as avant_lexer
from lexer import main as lexer
from tous_les_types import Parseur, afficher_ast, AnalyseurSemantique
import pprint as p
from interpreteur import Interpreteur

"""LANGAGE EVA"""
code_source: str
fichier_json: dict
code_source, fichier_json = avant_lexer()

original_code_source: str = code_source

token: list[dict] = lexer(code_source, fichier_json)
parseur = Parseur(token)
ast = parseur.parse_programme()
ANA_SEMAN = AnalyseurSemantique(ast)
ANA_SEMAN.visiter_algorithme()
interprete = Interpreteur()
interprete.interpreter(ast)
